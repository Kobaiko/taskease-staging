'use client'

import { Button } from "@/components/ui/button"
import { Layout, Sparkles, Clock, CheckCircle, ChevronRight } from "lucide-react"
import Link from "next/link"
import { useEffect, useState } from "react"

export default function Component() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0F1629] via-[#1E2A4A] to-[#0F1629] text-white">
      <header className="bg-gradient-to-r from-[#1a1f35] to-[#0F1629] border-b border-gray-800">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link className="flex items-center justify-center" href="#">
            <Layout className="h-6 w-6 text-[#6366F1]" />
            <span className="ml-2 text-xl font-bold">TaskEase</span>
          </Link>
          <nav className="flex items-center gap-6">
            <Link href="#" className="text-sm text-gray-300 hover:text-white transition-colors">
              Log in
            </Link>
            <Button className="bg-gradient-to-r from-[#6366F1] to-[#8B5CF6] hover:from-[#8B5CF6] hover:to-[#6366F1] text-white rounded-md px-6 transition-all duration-300">
              Sign up
            </Button>
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <section className="bg-gradient-to-b from-[#1a1f35] to-[#0F1629] py-24">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-tight tracking-tight max-w-4xl mx-auto mb-6 bg-clip-text text-transparent bg-gradient-to-r from-[#FF6B6B] via-[#6366F1] to-[#4ECDC4]">
              Transform Big Tasks into Manageable Steps
            </h1>
            <p className="mt-6 text-gray-300 text-xl max-w-2xl mx-auto">
              TaskEase uses AI to break down your complex tasks into simple, actionable subtasks. Get more done with less stress.
            </p>
            <Button className="mt-10 bg-gradient-to-r from-[#FF6B6B] to-[#4ECDC4] hover:from-[#4ECDC4] hover:to-[#FF6B6B] text-white text-lg px-8 py-6 rounded-md transition-all duration-300 transform hover:scale-105">
              Get Started
            </Button>
          </div>
        </section>

        <section className="py-24">
          <div className="container mx-auto px-4">
            <h2 className="text-4xl font-bold text-center mb-16 bg-clip-text text-transparent bg-gradient-to-r from-[#FF6B6B] via-[#6366F1] to-[#4ECDC4]">How TaskEase Works</h2>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                { icon: Sparkles, title: "AI-Powered Breakdown", description: "Our AI analyzes your tasks and automatically creates a detailed breakdown of subtasks.", color: "#FF6B6B" },
                { icon: Clock, title: "Time Estimation", description: "Get accurate time estimates for each subtask to better plan your work.", color: "#6366F1" },
                { icon: CheckCircle, title: "Progress Tracking", description: "Track your progress with visual indicators and completion percentages.", color: "#4ECDC4" }
              ].map((feature, index) => (
                <div key={index} className={`bg-gradient-to-br from-[#1a1f35] to-[#0F1629] rounded-lg p-8 border border-gray-800 transition-all duration-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`} style={{transitionDelay: `${index * 150}ms`}}>
                  <feature.icon className={`h-12 w-12 mb-6`} style={{color: feature.color}} />
                  <h3 className="text-xl font-bold mb-3 text-white">{feature.title}</h3>
                  <p className="text-gray-300">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-24 bg-gradient-to-b from-[#0F1629] to-[#1E2A4A]">
          <div className="container mx-auto px-4">
            <div className="flex flex-col lg:flex-row items-start gap-16">
              <div className="lg:w-1/2">
                <h2 className="text-5xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-[#FF6B6B] via-[#6366F1] to-[#4ECDC4]">See Your Tasks Transform</h2>
                <p className="text-gray-300 text-xl mb-8 leading-relaxed">
                  Watch as TaskEase breaks down your complex projects into simple, manageable steps. Our AI ensures no detail is missed.
                </p>
                <ul className="space-y-4">
                  {[
                    { text: "Smart task analysis", color: "#FF6B6B" },
                    { text: "Automatic time estimation", color: "#6366F1" },
                    { text: "Progress tracking", color: "#4ECDC4" }
                  ].map((item, index) => (
                    <li key={index} className="flex items-center text-lg text-white">
                      <CheckCircle className="h-6 w-6 mr-3 flex-shrink-0" style={{color: item.color}} />
                      <span>{item.text}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="lg:w-1/2 w-full">
                <div className="bg-gradient-to-br from-[#1a1f35] to-[#0F1629] rounded-lg p-6 border border-gray-800 transition-all duration-500 transform hover:scale-105">
                  <h3 className="text-xl font-bold mb-6">Build a marketing plan</h3>
                  <div className="space-y-6">
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-gray-300">Progress</span>
                        <span className="text-sm text-[#4ECDC4]">40%</span>
                      </div>
                      <div className="w-full bg-gray-800 rounded-full h-2">
                        <div className="bg-gradient-to-r from-[#FF6B6B] via-[#6366F1] to-[#4ECDC4] h-2 rounded-full" style={{ width: '40%' }}></div>
                      </div>
                    </div>
                    <ul className="space-y-4">
                      {[
                        { done: true, text: "Conduct market research (60m)" },
                        { done: true, text: "Identify target audience (30m)" },
                        { done: false, text: "Develop marketing goals (45m)" },
                        { done: false, text: "Create a budget (45m)" },
                        { done: false, text: "Plan marketing strategies (60m)" }
                      ].map((task, index) => (
                        <li key={index} className={`flex items-center ${task.done ? 'text-white' : 'text-gray-500'}`}>
                          <CheckCircle className={`h-5 w-5 mr-3 flex-shrink-0`} style={{color: task.done ? '#4ECDC4' : '#4A5568'}} />
                          <span>{task.text}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-24 bg-gradient-to-b from-[#1E2A4A] to-[#0F1629]">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-[#FF6B6B] via-[#6366F1] to-[#4ECDC4]">Ready to Get Started?</h2>
            <p className="text-gray-300 text-xl mb-8 max-w-2xl mx-auto">
              Join thousands of users who are already experiencing the power of AI-driven task management.
            </p>
            <Button className="bg-gradient-to-r from-[#FF6B6B] via-[#6366F1] to-[#4ECDC4] hover:from-[#4ECDC4] hover:via-[#6366F1] hover:to-[#FF6B6B] text-white text-lg px-8 py-6 rounded-md transition-all duration-300 transform hover:scale-105">
              Sign Up Now <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </section>
      </main>

      <footer className="border-t border-gray-800 py-8 bg-[#0F1629]">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center mb-4 md:mb-0">
              <Layout className="h-6 w-6 text-[#6366F1]" />
              <span className="ml-2 text-xl font-bold">TaskEase</span>
            </div>
            <p className="text-sm text-gray-400">© 2024 TaskEase. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}