'use client'

import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle, ChevronRight, Clock, Layout, Sparkles, Menu } from "lucide-react"
import Link from "next/link"

export default function LandingPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  return (
    <div className="min-h-screen bg-[#0F1629] text-white">
      <header className="px-4 lg:px-6 h-16 flex items-center justify-between border-b border-gray-800">
        <Link className="flex items-center justify-center" href="#">
          <Layout className="h-6 w-6 text-[#6366F1]" />
          <span className="ml-2 text-xl font-bold">TaskEase</span>
        </Link>
        <nav className="hidden md:flex gap-6 items-center">
          <Link href="#" className="text-sm hover:text-[#6366F1] transition-colors">Features</Link>
          <Link href="#" className="text-sm hover:text-[#6366F1] transition-colors">Pricing</Link>
          <Link href="#" className="text-sm hover:text-[#6366F1] transition-colors">About</Link>
          <Button variant="outline" className="text-white border-gray-600 hover:bg-gray-800">Log in</Button>
          <Button className="bg-[#6366F1] hover:bg-[#6366F1]/90">Sign up</Button>
        </nav>
        <Button variant="ghost" className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          <Menu className="h-6 w-6" />
        </Button>
      </header>
      {isMenuOpen && (
        <div className="md:hidden bg-[#1A2233] p-4">
          <nav className="flex flex-col gap-4">
            <Link href="#" className="text-sm hover:text-[#6366F1] transition-colors">Features</Link>
            <Link href="#" className="text-sm hover:text-[#6366F1] transition-colors">Pricing</Link>
            <Link href="#" className="text-sm hover:text-[#6366F1] transition-colors">About</Link>
            <Button variant="outline" className="text-white border-gray-600 hover:bg-gray-800 w-full">Log in</Button>
            <Button className="bg-[#6366F1] hover:bg-[#6366F1]/90 w-full">Sign up</Button>
          </nav>
        </div>
      )}
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48 px-4">
          <div className="container mx-auto">
            <div className="flex flex-col items-center space-y-4 text-center">
              <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl/none max-w-3xl">
                Transform Big Tasks into
                <span className="text-[#6366F1]"> Manageable Steps</span>
              </h1>
              <p className="mx-auto max-w-[700px] text-gray-400 md:text-xl">
                TaskEase uses AI to break down your complex tasks into simple, actionable subtasks.
                Get more done with less stress.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mt-8">
                <Button size="lg" className="bg-[#6366F1] hover:bg-[#6366F1]/90">
                  Get Started
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
                <Button size="lg" variant="outline" className="border-gray-600 hover:bg-gray-800">
                  Watch Demo
                </Button>
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32 bg-[#1A2233]">
          <div className="container mx-auto px-4">
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              <Card className={`bg-[#0F1629] border-gray-800 transition-all duration-500 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
                <CardContent className="p-6">
                  <Sparkles className="h-12 w-12 text-[#6366F1] mb-4" />
                  <h3 className="text-xl font-bold mb-2">AI-Powered Breakdown</h3>
                  <p className="text-gray-400">
                    Our AI analyzes your tasks and automatically creates a detailed breakdown of subtasks.
                  </p>
                </CardContent>
              </Card>
              <Card className={`bg-[#0F1629] border-gray-800 transition-all duration-500 delay-150 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
                <CardContent className="p-6">
                  <Clock className="h-12 w-12 text-[#6366F1] mb-4" />
                  <h3 className="text-xl font-bold mb-2">Time Estimation</h3>
                  <p className="text-gray-400">
                    Get accurate time estimates for each subtask to better plan your work.
                  </p>
                </CardContent>
              </Card>
              <Card className={`bg-[#0F1629] border-gray-800 transition-all duration-500 delay-300 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
                <CardContent className="p-6">
                  <CheckCircle className="h-12 w-12 text-[#6366F1] mb-4" />
                  <h3 className="text-xl font-bold mb-2">Progress Tracking</h3>
                  <p className="text-gray-400">
                    Track your progress with visual indicators and completion percentages.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container mx-auto px-4">
            <div className="grid gap-10 lg:grid-cols-2 lg:gap-20 items-center">
              <div className="space-y-4">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  See Your Tasks Transform
                </h2>
                <p className="text-gray-400 text-lg">
                  Watch as TaskEase breaks down your complex projects into simple, manageable steps. Our AI ensures no detail is missed.
                </p>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-[#6366F1]" />
                    <span>Smart task analysis</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-[#6366F1]" />
                    <span>Automatic time estimation</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-[#6366F1]" />
                    <span>Progress tracking</span>
                  </div>
                </div>
              </div>
              <div className={`rounded-lg border border-gray-800 bg-[#1A2233] p-6 transition-all duration-500 ${isVisible ? 'translate-x-0 opacity-100' : 'translate-x-10 opacity-0'}`}>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <h3 className="text-xl font-bold">Build a marketing plan</h3>
                    <div className="h-2 w-full rounded-full bg-gray-800">
                      <div className="h-2 w-1/3 rounded-full bg-[#6366F1]" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-[#6366F1]" />
                      <span className="text-sm">Conduct market research (60m)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-[#6366F1]" />
                      <span className="text-sm">Identify target audience (30m)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-gray-600" />
                      <span className="text-sm">Develop marketing goals (45m)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-gray-600" />
                      <span className="text-sm">Create a budget (45m)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-gray-600" />
                      <span className="text-sm">Plan marketing strategies (60m)</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32 bg-[#1A2233]">
          <div className="container mx-auto px-4">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Ready to Get Started?
              </h2>
              <p className="mx-auto max-w-[600px] text-gray-400 text-lg">
                Join thousands of users who are already experiencing the power of AI-driven task management.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mt-8">
                <Button size="lg" className="bg-[#6366F1] hover:bg-[#6366F1]/90">
                  Sign Up Now
                </Button>
                <Button size="lg" variant="outline" className="border-gray-600 hover:bg-gray-800">
                  Learn More
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t border-gray-800 py-6 bg-[#0F1629]">
        <div className="container mx-auto flex flex-col md:flex-row items-center justify-between gap-4 px-4">
          <div className="flex items-center">
            <Layout className="h-6 w-6 text-[#6366F1]" />
            <span className="ml-2 text-lg font-bold">TaskEase</span>
          </div>
          <p className="text-sm text-gray-400">© 2024 TaskEase. All rights reserved.</p>
          <nav className="flex gap-4">
            <Link className="text-sm hover:text-[#6366F1] transition-colors" href="#">
              Terms
            </Link>
            <Link className="text-sm hover:text-[#6366F1] transition-colors" href="#">
              Privacy
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  )
}