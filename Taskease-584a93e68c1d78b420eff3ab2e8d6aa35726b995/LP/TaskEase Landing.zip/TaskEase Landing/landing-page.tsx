'use client'

import { Button } from "@/components/ui/button"
import { Layout } from "lucide-react"
import Link from "next/link"

export default function Component() {
  return (
    <div className="min-h-screen bg-[#0F1629] text-white">
      <header className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link className="flex items-center justify-center" href="#">
          <Layout className="h-6 w-6 text-[#6366F1]" />
          <span className="ml-2 text-xl font-bold">TaskEase</span>
        </Link>
        <nav className="flex items-center gap-6">
          <Link href="#" className="text-sm text-gray-300 hover:text-white transition-colors">
            Log in
          </Link>
          <Button className="bg-[#6366F1] hover:bg-[#6366F1]/90 rounded-md px-6">
            Sign up
          </Button>
        </nav>
      </header>
      <main className="flex-1">
        <section className="container mx-auto px-4 py-24 text-center">
          <h1 className="text-[64px] font-bold leading-tight tracking-tight max-w-4xl mx-auto">
            Transform Big Tasks into{" "}
            <span className="text-[#6366F1]">Manageable Steps</span>
          </h1>
          <p className="mt-6 text-gray-400 text-xl max-w-2xl mx-auto">
            TaskEase uses AI to break down your complex tasks into simple, actionable subtasks. Get more done with less stress.
          </p>
          <Button className="mt-10 bg-[#6366F1] hover:bg-[#6366F1]/90 text-lg px-8 py-6 rounded-md">
            Get Started
          </Button>
        </section>
      </main>
    </div>
  )
}