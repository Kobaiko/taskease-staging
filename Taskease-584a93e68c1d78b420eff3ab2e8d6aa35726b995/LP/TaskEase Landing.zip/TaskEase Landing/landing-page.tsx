'use client'

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Layout, Sparkles, Clock, CheckCircle, ChevronRight } from "lucide-react"
import Link from "next/link"

export default function Component() {
  return (
    <div className="min-h-screen bg-[#0F1629] text-white">
      <header className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link className="flex items-center justify-center" href="#">
          <Layout className="h-6 w-6 text-[#6366F1]" />
          <span className="ml-2 text-xl font-bold">TaskEase</span>
        </Link>
        <nav className="flex items-center gap-6">
          <Link href="#" className="text-sm text-gray-300 hover:text-white transition-colors">
            Log in
          </Link>
          <Button className="bg-[#6366F1] hover:bg-[#6366F1]/90 rounded-md px-6">
            Sign up
          </Button>
        </nav>
      </header>
      <main className="flex-1">
        <section className="container mx-auto px-4 py-24 text-center">
          <h1 className="text-[64px] font-bold leading-tight tracking-tight max-w-4xl mx-auto">
            Transform Big Tasks into{" "}
            <span className="text-[#6366F1]">Manageable Steps</span>
          </h1>
          <p className="mt-6 text-gray-400 text-xl max-w-2xl mx-auto">
            TaskEase uses AI to break down your complex tasks into simple, actionable subtasks. Get more done with less stress.
          </p>
          <Button className="mt-10 bg-[#6366F1] hover:bg-[#6366F1]/90 text-lg px-8 py-6 rounded-md">
            Get Started
          </Button>
        </section>

        <section className="bg-[#1A2233] py-24">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">How TaskEase Works</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <Card className="bg-[#0F1629] border-gray-800">
                <CardContent className="p-6">
                  <Sparkles className="h-12 w-12 text-[#6366F1] mb-4" />
                  <h3 className="text-xl font-bold mb-2">AI-Powered Breakdown</h3>
                  <p className="text-gray-400">
                    Our AI analyzes your tasks and automatically creates a detailed breakdown of subtasks.
                  </p>
                </CardContent>
              </Card>
              <Card className="bg-[#0F1629] border-gray-800">
                <CardContent className="p-6">
                  <Clock className="h-12 w-12 text-[#6366F1] mb-4" />
                  <h3 className="text-xl font-bold mb-2">Time Estimation</h3>
                  <p className="text-gray-400">
                    Get accurate time estimates for each subtask to better plan your work.
                  </p>
                </CardContent>
              </Card>
              <Card className="bg-[#0F1629] border-gray-800">
                <CardContent className="p-6">
                  <CheckCircle className="h-12 w-12 text-[#6366F1] mb-4" />
                  <h3 className="text-xl font-bold mb-2">Progress Tracking</h3>
                  <p className="text-gray-400">
                    Track your progress with visual indicators and completion percentages.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="py-24">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center gap-12">
              <div className="md:w-1/2">
                <h2 className="text-4xl font-bold mb-6">See Your Tasks Transform</h2>
                <p className="text-gray-400 text-lg mb-8">
                  Watch as TaskEase breaks down your complex projects into simple, manageable steps. Our AI ensures no detail is missed.
                </p>
                <ul className="space-y-4">
                  <li className="flex items-center">
                    <CheckCircle className="h-6 w-6 text-[#6366F1] mr-2" />
                    <span>Smart task analysis</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-6 w-6 text-[#6366F1] mr-2" />
                    <span>Automatic time estimation</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-6 w-6 text-[#6366F1] mr-2" />
                    <span>Progress tracking</span>
                  </li>
                </ul>
              </div>
              <div className="md:w-1/2">
                <Card className="bg-[#1A2233] border-gray-800">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold mb-4">Build a marketing plan</h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Progress</span>
                        <span className="text-sm text-[#6366F1]">40%</span>
                      </div>
                      <div className="w-full bg-gray-800 rounded-full h-2.5">
                        <div className="bg-[#6366F1] h-2.5 rounded-full" style={{ width: '40%' }}></div>
                      </div>
                      <ul className="space-y-2">
                        <li className="flex items-center text-sm">
                          <CheckCircle className="h-4 w-4 text-[#6366F1] mr-2" />
                          <span>Conduct market research (60m)</span>
                        </li>
                        <li className="flex items-center text-sm">
                          <CheckCircle className="h-4 w-4 text-[#6366F1] mr-2" />
                          <span>Identify target audience (30m)</span>
                        </li>
                        <li className="flex items-center text-sm text-gray-400">
                          <CheckCircle className="h-4 w-4 text-gray-600 mr-2" />
                          <span>Develop marketing goals (45m)</span>
                        </li>
                        <li className="flex items-center text-sm text-gray-400">
                          <CheckCircle className="h-4 w-4 text-gray-600 mr-2" />
                          <span>Create a budget (45m)</span>
                        </li>
                        <li className="flex items-center text-sm text-gray-400">
                          <CheckCircle className="h-4 w-4 text-gray-600 mr-2" />
                          <span>Plan marketing strategies (60m)</span>
                        </li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        <section className="bg-[#1A2233] py-24">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-4xl font-bold mb-6">Ready to Get Started?</h2>
            <p className="text-gray-400 text-lg mb-8 max-w-2xl mx-auto">
              Join thousands of users who are already experiencing the power of AI-driven task management.
            </p>
            <Button className="bg-[#6366F1] hover:bg-[#6366F1]/90 text-lg px-8 py-6 rounded-md">
              Sign Up Now <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </section>
      </main>

      <footer className="bg-[#0F1629] border-t border-gray-800 py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center mb-4 md:mb-0">
              <Layout className="h-6 w-6 text-[#6366F1]" />
              <span className="ml-2 text-xl font-bold">TaskEase</span>
            </div>
            <nav className="flex gap-6">
              <Link href="#" className="text-sm text-gray-400 hover:text-white transition-colors">
                Terms
              </Link>
              <Link href="#" className="text-sm text-gray-400 hover:text-white transition-colors">
                Privacy
              </Link>
            </nav>
          </div>
          <p className="text-center text-sm text-gray-400 mt-8">
            © 2024 TaskEase. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}